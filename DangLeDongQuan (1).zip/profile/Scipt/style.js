const menu = document.querySelectorAll('.navbar-nav');
menu.onclick = function () {
    console.log([menu]);
}